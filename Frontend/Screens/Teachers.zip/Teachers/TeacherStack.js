// Navigation/TeacherStack.js

import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import Sidebar            from './Sidebar';
import MainDash           from './MainDash';
import Attendance         from './Attendance';
import AttendanceRecord   from './AttendanceRecords';
import Timetable          from './Timetable';
import QuizSession        from './QuizzSessionScreen';
import Analytics          from './StudentAttendanceScreen';
import Addquizz           from './Addquizz';
import TeacherExamScreen  from './TeacherExamScreen';
import Assignments        from './AssignmentScreen';
import Lessonplanner      from './LessonPlanner';
import DoubtSession       from './Doubtsessionscreen';
import DoubtSolveScreen   from './Doubtsolvescreen';
import SelectionScreen    from './Selectionscreen';
import MessagingScreen    from './Messagingscreen';
import Quizresultscreen   from './Quizresultscreen';

const Stack = createNativeStackNavigator();

export default function TeacherStack({ route }) {
  const user = route?.params?.user || {};

  return (
    <Stack.Navigator
      initialRouteName="DashboardScreen"
      screenOptions={{ headerShown: false, animation: 'slide_from_right' }}
    >
      {/* ── Screens wrapped in Sidebar ────────────────────────────────── */}
      <Stack.Screen name="DashboardScreen">
        {() => <Sidebar activeScreen="dashboard" user={user}><MainDash user={user} /></Sidebar>}
      </Stack.Screen>

      <Stack.Screen name="AttendanceScreen">
        {() => <Sidebar activeScreen="attendance" user={user}><Attendance user={user} /></Sidebar>}
      </Stack.Screen>

      <Stack.Screen name="AssignmentScreen">
        {() => <Sidebar activeScreen="assignments" user={user}><Assignments user={user} /></Sidebar>}
      </Stack.Screen>

      <Stack.Screen name="StudentAttendanceScreen">
        {() => <Sidebar activeScreen="Attendance" user={user}><Analytics user={user} /></Sidebar>}
      </Stack.Screen>

      <Stack.Screen name="PlannerScreen">
        {() => <Sidebar activeScreen="planner" user={user}><Lessonplanner user={user} /></Sidebar>}
      </Stack.Screen>

      <Stack.Screen name="QuizzSessionScreen">
        {() => <Sidebar activeScreen="quizSessions" user={user}><QuizSession user={user} /></Sidebar>}
      </Stack.Screen>

      <Stack.Screen name="DoubtScreen">
        {() => (
          <Sidebar activeScreen="doubt" user={user}>
            <DoubtSession />
          </Sidebar>
        )}
      </Stack.Screen>

      {/* ── Doubt SOLVE — full-screen, no Sidebar ─────────────────────── */}
      <Stack.Screen
        name="DoubtSolveScreen"
        component={DoubtSolveScreen}
        options={{ animation: 'slide_from_right' }}
      />

      <Stack.Screen name="TeacherExamScreen">
        {() => <Sidebar activeScreen="exams" user={user}><TeacherExamScreen user={user} /></Sidebar>}
      </Stack.Screen>

      {/* ── Messages → directly renders SelectionScreen inside Sidebar ── */}
      <Stack.Screen name="MessagesScreen">
        {() => (
          <Sidebar activeScreen="messages" user={user}>
            <SelectionScreen />
          </Sidebar>
        )}
      </Stack.Screen>

      {/* ── Full-screen broadcast screens (no Sidebar) ────────────────── */}
      <Stack.Screen name="SelectionScreen"  component={SelectionScreen}  />
      <Stack.Screen name="MessagingScreen"  component={MessagingScreen}  />

      <Stack.Screen name="TimetableScreen">
        {() => <Sidebar activeScreen="timetable" user={user}><Timetable user={user} /></Sidebar>}
      </Stack.Screen>

      <Stack.Screen name="QuizBuilderScreen">
        {() => <Sidebar activeScreen="QuizBuilder" user={user}><Addquizz user={user} /></Sidebar>}
      </Stack.Screen>

      <Stack.Screen name="AttendanceRecord">
        {({ route }) => <AttendanceRecord route={route} />}
      </Stack.Screen>

      <Stack.Screen name="QuizResultScreen" component={Quizresultscreen} />
    </Stack.Navigator>
  );
}